bin/micromamba run -r runtime -n koboldai-rocm bash
